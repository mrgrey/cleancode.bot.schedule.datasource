-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 16 2009 г., 00:56
-- Версия сервера: 5.1.33
-- Версия PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `cleancode_bot_schedule_datasource_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Schedule`
--

CREATE TABLE IF NOT EXISTS `Schedule` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ScheduleId` int(11) NOT NULL,
  `GroupNumber` int(11) NOT NULL,
  `WeekType` int(11) NOT NULL COMMENT 'Тип недели (четная/нечетная)',
  `DayOfWeek` int(11) NOT NULL,
  `Time` varchar(30) NOT NULL,
  `Place` varchar(100) NOT NULL,
  `Subject` varchar(255) NOT NULL,
  `Person` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;
